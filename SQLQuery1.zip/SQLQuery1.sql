CREATE TABLE Venue (
    VenueID INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(100),
    Location NVARCHAR(255),
    Capacity INT,
    ImageUrl NVARCHAR(255)
);

CREATE TABLE Event (
    EventID INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(100),
    StartDate DATE,
    EndDate DATE,
    Description NVARCHAR(500),
    ImageUrl NVARCHAR(255)
);

CREATE TABLE Booking (
    BookingID INT PRIMARY KEY IDENTITY,
    EventID INT FOREIGN KEY REFERENCES Event(EventID),
    VenueID INT FOREIGN KEY REFERENCES Venue(VenueID),
    BookingDate DATE,
    Status NVARCHAR(20)
);
